GCMS_time_factor <- function(units) {
  units<-if(is.null(units))""else tolower(trimws(as.character(units)))
  if (!nzchar(units)||grepl("^s(ec(ond)?s?)?$",units)) 1/60 else
    if(grepl("^min(ute)?s?$",units)) 1 else if(grepl("^ms$|^milliseconds?$",units)) 1/60000 else
      stop("Unrecognized scan time units: ",units,call.=FALSE)
}

GCMS_range <- function(value, name) {
  if (!is.null(value) && (!is.numeric(value) || length(value)!=2L || anyNA(value) || value[1L]>=value[2L]))
    stop(name, " must contain increasing lower and upper retention times in minutes.",call.=FALSE)
  value
}

GCMS_read_cdf <- function(cdf_file, time_range=NULL, mass=NULL) {
  if (!requireNamespace("ncdf4",quietly=TRUE)) stop("Install ncdf4 to read ANDI-MS files.",call.=FALSE)
  if (!is.character(cdf_file)||length(cdf_file)!=1L||is.na(cdf_file)||!nzchar(cdf_file))
    stop("cdf_file must be a local file path or HTTP(S) URL.",call.=FALSE)
  local <- cdf_file
  if (grepl("^https?://",cdf_file,ignore.case=TRUE)) {
    local <- tempfile(fileext=".cdf");on.exit(unlink(local),add=TRUE)
    utils::download.file(cdf_file,local,mode="wb",quiet=TRUE)
  }
  nc <- ncdf4::nc_open(local)
  on.exit(ncdf4::nc_close(nc),add=TRUE,after=FALSE)
  required <- c("point_count","scan_index","scan_acquisition_time","mass_values","intensity_values")
  if (!all(required %in% c(names(nc$var),names(nc$dim))))
    stop("The CDF needs ANDI-MS scan, mass and intensity variables.",call.=FALSE)
  get <- function(name,...) ncdf4::ncvar_get(nc,name,...)
  counts <- as.numeric(get("point_count"));starts <- as.numeric(get("scan_index"))
  time <- as.numeric(get("scan_acquisition_time"));n <- length(time)
  points <- prod(nc$var[["mass_values"]]$varsize)
  if (!n || length(counts)!=n || length(starts)!=n ||
      any(!is.finite(counts)|counts<0|counts!=floor(counts)) ||
      any(!is.finite(starts)|starts<0|starts!=floor(starts)) ||
      any(starts+counts>points) || any(diff(starts)<head(counts,-1L)) ||
      prod(nc$var[["intensity_values"]]$varsize)!=points)
    stop("CDF scan indices and point counts are inconsistent.",call.=FALSE)
  if (any(!is.finite(time)|time<0)||any(diff(time)<=0)) stop("Scan times must be finite and increasing.",call.=FALSE)
  att <- ncdf4::ncatt_get(nc,"scan_acquisition_time","units")
  units <- if(isTRUE(att$hasatt)) tolower(trimws(as.character(att$value))) else ""
  factor <- GCMS_time_factor(units)
  minutes <- time*factor;time_range <- GCMS_range(time_range,"time_range")
  rows <- if(is.null(time_range)) seq_len(n) else which(minutes>=time_range[1L]&minutes<=time_range[2L])
  if(!length(rows)) stop("No scans in the requested retention-time range.",call.=FALSE)
  first <- starts[rows[1L]];span <- max(starts[rows]+counts[rows])-first
  if(span<=0||sum(counts[rows])==0) {
    if(is.null(mass)) stop("No mass/intensity points in the requested scans.",call.=FALSE)
    return(list(Y=matrix(0,length(rows),length(mass)),time=minutes[rows],mass=mass,
      source=cdf_file,scans=rows,scan_time_units=units))
  }
  take <- sequence(as.integer(counts[rows]))+rep(starts[rows]-first,counts[rows])
  mz <- as.numeric(get("mass_values",start=first+1,count=span))[take]
  intensity <- as.numeric(get("intensity_values",start=first+1,count=span))[take]
  if(any(!is.finite(mz)|mz<0)||any(!is.finite(intensity)|intensity<0))
    stop("CDF masses and intensities must be finite and nonnegative.",call.=FALSE)
  nominal <- floor(mz+.5)
  if(is.null(mass)) mass <- seq.int(min(nominal),max(nominal))
  channel <- match(nominal,mass);keep <- !is.na(channel)
  Y <- as.matrix(Matrix::sparseMatrix(i=rep.int(seq_along(rows),counts[rows])[keep],
    j=channel[keep],x=intensity[keep],dims=c(length(rows),length(mass))))
  dimnames(Y) <- list(format(minutes[rows],digits=12,trim=TRUE),as.character(mass))
  list(Y=Y,time=minutes[rows],mass=mass,source=cdf_file,scans=rows,
    scan_time_units=if(nzchar(units)) units else "ANDI-MS seconds (units omitted)")
}

GCMS_compounds <- function(model,time,sample_name="L0glm") {
  apex <- vapply(seq_len(ncol(model$H)),function(k) which.max(model$H[,k]),0L)
  order <- order(time[apex]);area <- rowSums(model$S);delta <- diff(time)
  quadrature <- if(length(time)>1L) c(delta[1L]/2,
    if(length(time)>2L) (head(delta,-1L)+tail(delta,-1L))/2,tail(delta,1L)/2) else 0
  integrated <- as.numeric(Matrix::crossprod(model$H,quadrature))*area
  names <- sprintf("%s_%04d_RT%.5f",sample_name,seq_along(order),time[apex[order]])
  data.frame(sample=rep(sample_name,length(order)),compound=order,name=names,
    retention_time=time[apex[order]],apex_scan=apex[order],area=area[order],
    area_min=integrated[order],n_ions=rowSums(model$S>0)[order],row.names=NULL)
}

GCMS_write_msp <- function(model,time,mass,msp_file,compounds=NULL,ion_threshold=.001) {
  if(nrow(model$H)!=length(time)||ncol(model$S)!=length(mass))
    stop("Profile, spectrum and scan/mass dimensions differ.",call.=FALSE)
  if(!is.character(msp_file)||length(msp_file)!=1L||is.na(msp_file)||!nzchar(msp_file)||
      !grepl("\\.msp$",msp_file,ignore.case=TRUE)) stop("msp_file must end in .msp.",call.=FALSE)
  if(is.null(compounds)) compounds <- GCMS_compounds(model,time)
  spectra<-GCMS_report_spectra(model$S,ion_threshold)
  compounds$n_ions<-rowSums(spectra>0)[compounds$compound]
  order <- compounds$compound;names <- compounds$name
  lines <- unlist(lapply(seq_along(order),function(index) {
    k<-order[index];s<-spectra[k,];keep<-which(s>0)
    if(!length(keep)) stop("Cannot export an empty compound spectrum.",call.=FALSE)
    abundance<-999*s[keep]/max(s[keep])
    annotation<-character()
    if('retention_index'%in%names(compounds)&&is.finite(compounds$retention_index[index])) {
      phase<-if(is.null(compounds$ri_phase))"User"else compounds$ri_phase[index]
      tag<-switch(phase,DB5="SemiStdNP",DB1="StdNP",DBWAX="StdPolar","User")
      annotation<-c(annotation,sprintf("Retention_index: %s=%.6f",tag,compounds$retention_index[index]))
    }
    if('match_name'%in%names(compounds)&&!is.na(compounds$match_name[index]))
      annotation<-c(annotation,sprintf("Synon: Tentative library match: %s; %s score %.4f; delta RI %.4f%s",
        gsub("[\r\n]"," ",compounds$match_name[index]),compounds$match_method[index],
        compounds$match_score[index],compounds$match_delta_RI[index],
        if('match_ri_assumed'%in%names(compounds)&&isTRUE(compounds$match_ri_assumed[index]))
          paste0("; reference RI column assumed ",compounds$ri_phase[index]) else ""))
    coordinate<-if('retention_coordinate'%in%names(compounds)&&is.finite(compounds$retention_coordinate[index]))
      sprintf("; RI retention coordinate %.7g min (1%% onset plus half local narrow-peak width)",
        compounds$retention_coordinate[index])else ""
    c(paste0("Name: ",names[index]),annotation,sprintf("Pseudocount: %.15g",sum(s)),
      sprintf("Ion_threshold: %.9g",ion_threshold),
      sprintf("Comments: Sample %s; apex retention time %.7g min; integrated ion intensity %.9g; logconNMF%s%s",
        compounds$sample[index],compounds$retention_time[index],sum(s),
        coordinate,
        if('ri_extrapolated'%in%names(compounds)&&isTRUE(compounds$ri_extrapolated[index]))
          "; retention index extrapolated beyond alkane anchors"else ""),
      sprintf("Num Peaks: %d",length(keep)),sprintf("%d %.8g;",mass[keep],abundance),"")
  }),use.names=FALSE)
  dir.create(dirname(msp_file),recursive=TRUE,showWarnings=FALSE)
  con<-file(msp_file,"wb");on.exit(close(con))
  writeLines(as.character(lines),con,sep="\r\n",useBytes=TRUE)
  compounds
}

#' Deconvolve a GC/MS chromatogram and export its compound spectra
#'
#' Read an ANDI-MS netCDF chromatogram, estimate a smoothly time-varying point
#' spread function, recover log-concave compounds with [logconNMF::logconNMF()], and
#' write a NIST-compatible MSP spectral library. All original mass channels
#' are retained in the final spectra.
#'
#' @param output_dir Directory for batch results; defaults to a sibling directory
#'   named after the input folder with suffix `_GCMSprime`.
#' @param coupled Logical; for directory input, use simultaneous NMF to share
#'   spectra while retaining sample-specific profiles and areas. Set to `FALSE`
#'   to export only the independent sample fits.
#' @param batch Named directory options; see [GCMSbatch].
#' @name gcmsDeco
#' @order 1
#' @param cdf_file A directory of sample subdirectories with a `standards`
#'   subdirectory, or a local ANDI-MS \code{.cdf} path or HTTP(S) URL. The optional
#'   \pkg{ncdf4} package is required. Masses are binned to the nearest integer
#'   m/z; traces between the minimum and maximum recorded mass are retained.
#' @param msp_file Output \code{.msp} path. Parent directories are created if
#'   necessary; an existing output file is replaced.
#' @param xlsx_file Optional Excel output path. The workbook contains compound
#'   areas and one spectrum column on the first sheet, followed by run metadata
#'   including the sample name. Fragments use \code{m/z (intensity)}, sorted by
#'   decreasing intensity and scaled to base peak 9999; fragments rounding to
#'   zero are omitted from this display. Requires
#'   the optional \pkg{openxlsx} package. \code{NULL} omits Excel export.
#' @param sample_name Sample identifier, defaulting to the CDF filename without
#'   its extension. Included in the compound table, MSP entries and workbook.
#' @param normalize Spectral coefficient normalization: \code{"none"} returns
#'   integrated channel intensities; \code{"l1"} gives a unit-sum spectrum per
#'   compound, with its magnitude carried by the compound area.
#' @param ion_threshold Reported ion-intensity cutoff as a fraction of each
#'   spectrum's base peak, default \code{0.001} (0.1%). Applied consistently to
#'   coefficient summaries, library queries, MSP and Excel spectra. Retained
#'   intensities are rescaled to preserve the fitted total ion pseudocount.
#'   Use zero to retain every positive ion. The fitted model, profiles, peak
#'   areas and information criteria are unaffected; raw factors remain in
#'   \code{model$S}.
#' @param family Identity-link noise model accepted by [logconNMF::logconNMF()].
#'   The default \code{quasipoisson("identity")} estimates one pooled dispersion
#'   across channels, suitable for overdispersed instrumental intensities.
#' @param lambda Information-criterion preset or a nonnegative numeric penalty.
#'   The conditional solver charges a numeric penalty per dimension of the
#'   spectrum and log-concave profiles. For the general solver the numeric
#'   value specifies the total charge per single-sample compound and the
#'   charge per selection degree of freedom in a joint fit.
#' @param ncores Total logical-CPU budget. \code{NULL} uses physical cores for
#'   one chromatogram and logical cores for directory input. Directory analyses
#'   run up to \code{min(samples,ncores)} sample workers,
#'   dividing native threads between them. For conditional grouped regressions
#'   automatic worker allocation also accounts for available memory. BLAS
#'   threads are limited during batch fitting and restored on return. Compatible
#'   count-model batches also read CDFs and estimate noise concurrently. After the
#'   PSF workers exit, the joint count solver reuses the budget for sample profiles
#'   and ion columns of the shared spectra.
#'   For a single chromatogram, this sets its native OpenMP thread count.
#' @param nwindows Number of overlapping blind-PSF windows, default \code{10L}.
#'   \code{1L} uses a shared PSF. The returned sparse design interpolates the
#'   PSFs smoothly across the chromatogram.
#' @param alkanes_file Optional ANDI-MS alkane-standard chromatogram. Isolated
#'   peaks calibrate the initial PSF through [logconNMF::estimatePSF()], with automatic
#'   support, sample refinement and resampling to the sample scan interval.
#' @param time_range Optional increasing pair of sample retention-time bounds
#'   in minutes. Infinite bounds are accepted. This can exclude the solvent
#'   interval or select a chromatographic window.
#' @param calibration_range Optional retention-time bounds in minutes for the
#'   standard. The whole standard is used when omitted.
#' @param baseline_df Dimension of the nonnegative cubic B-spline background.
#'   Use \code{1L} for a constant background in a short window. A spline uses
#'   at least four basis functions.
#'   \code{NULL} chooses a low-dimensional basis from the scan count and typical
#'   PSF width; an integer of at least four fixes its dimension.
#' @param psf_control Named PSF settings. Entries `method`, `standard`,
#'   `precluster`, `weights` and `offset` are passed directly to [logconNMF::estimatePSF()].
#'   Other entries form its `control` list, for example
#'   `list(kernel_est=psf, maxiter=0L)` keeps a supplied PSF fixed and
#'   `list(L=61L, maxiter=8L, tol=1e-3)` estimates a PSF on the sample.
#'   `list(standard=attr(gcmsData2, "alkanes_TIC"))` uses the bundled calibration
#'   TIC; its numeric names supply retention times. `precluster=1L` uses the
#'   total-ion signal, `FALSE` the original channels, and `32L` at most 32 groups.
#'   A fitted `estimatePSF(method="standard")` result can be passed as
#'   `standard` with `method="standard"` to reuse a solvent-trimmed ladder
#'   calibration across samples, rebuilding each sparse design on its own grid.
#'   The PSF uses the same noise family and fixed noise estimates as the final
#'   factorization, with its information adjustment included in the weights.
#' @inheritParams logconNMF::splogconNMF
#' @param object,x A fitted \code{gcmsDeco} object.
#'
#' @details
#' **File formats.** ANDI-MS variables \code{scan_index}, \code{point_count},
#' \code{scan_acquisition_time}, \code{mass_values} and \code{intensity_values}
#' define the scan spectra. Scan indices are zero-based. Padding between scans
#' is accepted. Intensities must be finite and nonnegative. Times are converted
#' to minutes; absent units use the ANDI-MS seconds convention. The selected
#' retention-time interval is read directly from the point arrays.
#'
#' MSP entries are ordered by profile apex time, with a unique compound name,
#' retention time and integrated ion intensity in the comments, followed by
#' mass/intensity pairs. Exported spectra have base peak 999 and use
#' \code{ion_threshold}. \code{coef()} returns thresholded fitted ion totals;
#' \code{normalize="l1"} returns unit-L1 spectra. The original factors remain
#' available in \code{model$S}. The spreadsheet's compact spectrum text uses
#' the same cutoff, followed by display rounding.
#' Their compound profiles are \eqn{P_{ir}=H_{ir}\sum_j S_{rj}}, preserving
#' \eqn{HS=PT}. The workbook reports \code{area}, equal to \eqn{\sum_j S_{rj}}, in
#' intensity-scans, and \code{area_min}, the trapezoidal integral of
#' \eqn{P_{\cdot r}} over retention time, in intensity-minutes.
#'
#' The returned object stores the factors and source CDF path. Observed data
#' are loaded from the CDF only when a plot needs them. Fitted signals are
#' reconstructed from the factors; the observed matrix is released after fitting.
#'
#' **PSF and background.** [logconNMF::estimatePSF()] estimates constant or smoothly
#' time-varying PSFs from the sample, optionally starting from an alkane standard.
#' Original channels, outcome groups and the total-ion signal are supported.
#' Interpolated columns are projected to log concavity on their local support
#' and normalized to unit sum. Their typical full width at half maximum,
#' \eqn{w}, sets the background dimension to
#' \deqn{q=\max\{4,\min[40,3+\lceil n/(50w)\rceil]\}.}
#' This places knots about 50 narrow-peak FWHMs apart. Each background
#' basis coefficient has a channel-specific spectrum, allowing slow spectral
#' drift across the chromatogram. Rank selection is conditional on this basis.
#' Background coefficients are nonnegative and unpenalized. This keeps the
#' baseline much smoother than an individual elution peak.
#' The calibrated median PSF width also sets the guard for the final
#' broad-profile fusion pass in [logconNMF::logconNMF()]. Set
#' \code{control=list(profile_fusion=FALSE)} to disable that pass.
#'
#' **Shared noise model.** Noise parameters are estimated once from the
#' original channels and reused in PSF estimation and factorization. The PSF
#' weights include the information adjustment \eqn{1/\kappa}, where
#' \eqn{\kappa=1+2\widehat\rho_1}. Aggregation adjusts the variance parameters
#' according to the selected family; NB2 and ordinary Gamma use moment matching.
#' See [logconNMF::estimatePSF()] for the distributional details. The returned
#' `psf_working_weight` summarises the average Poisson-scale precision for
#' comparing noise scales; the actual PSF likelihood uses the specified family.
#'
#' With the conditional count solver, a grouped PSF regression supplies starting
#' spectra. The final iterations use every ion, count the positive spectral
#' coefficients and the free ordinates of each log-concave curve. Multiple
#' samples share spectra on their native scan grids. Explicit numeric lambda
#' is per fitted dimension for this solver. See the mathematical basis article.
#'
#' With the general solver, \code{precluster=32L} performs selection and fusion in at most 32 size-adjusted
#' outcome groups, followed by refinement on every original channel. The final
#' original-channel cleanup checks deletions, local fusions and missed residual
#' peaks using the complete compound-count criterion. Its diagnostics are in
#' `model$cleanup`; `control=list(original_cleanup=FALSE)` skips it. See
#' [logconNMF::logconNMF()] for the selection criterion and shape constraints. The
#' backend uses a permissive component initialization, native log-concave
#' profile/spectrum refinement, and final rank selection with the requested
#' working-correlation adjustment. Small fragments contained in a broad peak
#' are assessed against equally refined unmerged local fits on every original
#' ion channel. Trial diagnostics are in `model$contained_fusion`; the
#' initialization criterion and history are in `model$initialization`.
#' Initial component selection uses the solver configured by
#' `control$initial_solver`, a named list of [L0glm::controlSolverGen()]
#' arguments. For a full chromatogram, for example,
#' `control=list(initial_solver=list(solver="eigen", method=3L, precond=1L))`
#' requests conjugate gradients with diagonal preconditioning. `max.memory`
#' in that list specifies the Gram/factor workspace budget in GiB. By default,
#' a Cholesky workspace-budget error triggers a reported retry with this CG
#' solver, preserving the memory limit and selection settings. Set
#' `control=list(initial_fallback=FALSE)` to disable the retry.
#' Compatible Poisson/quasipoisson fits reuse the ion groups to screen local
#' width restarts. Promising candidates and matched controls are refined and
#' accepted using all original channels, with background and noise settings
#' fixed. Other cases retain original-channel screening. Screening channel
#' counts, accepted changes and cache diagnostics are in `model$profile_starts`.
#' The
#' spreadsheet and returned coefficient rows use increasing apex retention time. Rank selection,
#' hard log concavity, censored Gamma intensities and compound-count information
#' criteria follow [logconNMF::logconNMF()].
#' The conditional solver uses grouped PSF regressions followed by original-ion
#' updates of shared spectra, sample profiles and background. Its peak memory
#' includes the raw count matrices and fitted means. For disk-backed joint
#' refinement use `batch=list(cache=FALSE)`.
#'
#' @section Experimental GC/MS examples:
#' The [GC/MS deconvolution tutorial](../articles/gcms-deconvolution.html)
#' converts the bundled [gcmsData1] and [gcmsData2] matrices to CDF, fits the
#' full-channel models and exports their spectra. It includes timings,
#' information criteria and all plot types, alongside the algorithm.
#' \if{html}{
#' \strong{gcmsData1: overlapping cuticular hydrocarbons.}
#' \figure{gcms-data1-traces.png}{Background-corrected observed mass traces and fitted compounds.}
#' \figure{gcms-data1-heatmaps.png}{Observed, corrected, fitted and Pearson-residual heatmaps.}
#' \figure{gcms-data1-profiles-spectra.png}{Recovered elution profiles and mass spectra.}
#' \strong{gcmsData2: beer volatiles with an asymmetric acid peak.}
#' \figure{gcms-data2-traces.png}{Observed ion traces and fitted beer-volatile components.}
#' \figure{gcms-data2-heatmaps.png}{Full-channel signal and Pearson-residual heatmaps.}
#' \figure{gcms-data2-profiles-spectra.png}{Representative compound profiles and mass spectra.}
#' }
#'
#' @param library Optional GCMSlibrary for retention-index-constrained identification.
#' @param objective.trace Record original-ion objective values after each
#'   conditional block. Leave FALSE for elapsed-time measurements.
#' @param truth.profiles Optional known elution profiles for the conditional
#'   count solver. Supply a scan-by-compound matrix for one CDF, or one matrix
#'   or simulator truth record per sample for a directory. Name the list by
#'   unique CDF basenames without extensions or by manifest sample IDs.
#'   Matched compound IDs identify columns across samples. The usual fit and
#'   a second fit initialised from the profiles are scored on the same counts.
#'   Their signed percentage difference in GIC is the empirical optimality gap.
#'   Inspect `fit$gic_gap` and use `plot(fit$gic_gap)` for a single or coupled
#'   fit. Independent directory fits return one diagnostic per sample.
#'   See [logconNMF::gicGap()] for the definition.
#' @param search Named options for librarySearch(), such as phase="DB5",
#'   ri_tolerance=30, n_matches=5 and method="stein_scott". The alkane file supplies
#'   RI calibration automatically; a precomputed calibration can be supplied here.
#'   Identification is stored in the returned object and included in MSP/Excel exports.
#'
#' Directory input returns a [GCMSbatch] object, with acquisition-ordered sample
#' groups, per-sample exports and a consensus area table and spectral library.
#'
#' @return An object of class \code{gcmsDeco} containing \code{model} (the full
#'   factorization), a \code{compounds} table with names, retention times,
#'   original-file apex scan indices, integrated intensities and ion counts,
#'   the unified PSF estimate and sparse design in \code{psf}, optional standard calibration
#'   in \code{psf_standard}, \code{background_df}, \code{psf_width_scans},
#'   an average precision diagnostic, retention-time and mass axes, original scan
#'   indices, sample identity, output file paths and stage timings. Coefficient, fitted-value,
#'   log-likelihood and information-criterion methods delegate to \code{model}.
#' @references NIST MS Search user manual, section on NIST text format:
#'   \url{https://chemdata.nist.gov/mass-spc/ms-search/docs/Ver20Man.pdf}.
#' @seealso [writeGCMSCDF()], [plot.GCMSdeco()], [logconNMF::logconNMF()], [logconNMF::estimatePSF()], [l0glmBlindDeco()]
#' @md
#' @example examples/gcmsDeco.R
#' @importFrom stats AIC BIC residuals
#' @export
gcmsDeco <- function(cdf_file,msp_file=NULL,family=quasipoisson("identity"),lambda="gic",nwindows=10L,
                     alkanes_file=NULL,time_range=NULL,calibration_range=NULL,
                     baseline_df=NULL,precluster=32L,dispersion=NULL,theta=NULL,
                     correlation=c("auto","none","lag1"),
                     ncores=NULL,control=list(),psf_control=list(),verbose=FALSE,
                     xlsx_file=NULL,sample_name=NULL,library=NULL,search=list(),
                     output_dir=NULL,coupled=TRUE,batch=list(),ion_threshold=.001,
                     objective.trace=FALSE,truth.profiles=NULL) {
  invisible(GCMS_report_spectra(matrix(numeric(),0L,0L),ion_threshold))
  args<-as.list(environment())
  if(length(cdf_file)==1L&&dir.exists(cdf_file))
    return(do.call(GCMSdeco_directory,args))
  args[c("output_dir","coupled","batch")]<-NULL
  do.call(GCMS_fit_cdf,args)
}

GCMS_fit_cdf <- function(cdf_file,msp_file,family,lambda,nwindows,alkanes_file,time_range,
                         calibration_range,baseline_df,precluster,dispersion,theta,correlation,
                         ncores,control,psf_control,verbose,xlsx_file=NULL,sample_name=NULL,
                         library=NULL,search=list(),ion_threshold=.001,objective.trace=FALSE,
                         truth.profiles=NULL,initial_only=FALSE) {
  if(is.null(msp_file))stop("Supply msp_file for a single chromatogram.")
  begun<-proc.time()[["elapsed"]];seconds<-numeric()
  if(!is.list(search)||length(search)&&(is.null(names(search))||any(!nzchar(names(search)))||
      anyDuplicated(names(search))||any(names(search)%in%c("x","library","msp_file","xlsx_file"))))
    stop("Use named library-search options in search.")
  if(is.null(library)&&length(search)) stop("Supply library when specifying search options.")
  ncores<-GCMS_threads(ncores)
  if(length(nwindows)!=1L||!is.finite(nwindows)||nwindows<1L||nwindows!=floor(nwindows)) stop("Use a positive integer nwindows.")
  if(is.null(sample_name)) sample_name<-tools::file_path_sans_ext(basename(sub("[?#].*$","",cdf_file)))
  if(!is.character(sample_name)||length(sample_name)!=1L||is.na(sample_name)||!nzchar(trimws(sample_name)))
    stop("sample_name must be a nonempty string.",call.=FALSE)
  if(!is.null(xlsx_file)) GCMS_xlsx_path(xlsx_file)
  GCMS_range(calibration_range,"calibration_range")
  if(!is.character(msp_file)||length(msp_file)!=1L||is.na(msp_file)||
      !grepl("\\.msp$",msp_file,ignore.case=TRUE)) stop("msp_file must end in .msp.",call.=FALSE)
  if(!is.list(psf_control)||length(psf_control)&&(is.null(names(psf_control))||
      any(!nzchar(names(psf_control)))||anyDuplicated(names(psf_control)))) stop("Use a named psf_control list.",call.=FALSE)
  if(any(c("y","nwindows") %in% names(psf_control))) stop("Pass data and nwindows as gcmsDeco arguments.",call.=FALSE)
  timed<-function(label,expression) {
    seconds[label]<<-GCMS_time(value<-force(expression))[["elapsed"]]
    if(verbose){cat(label,": ",round(seconds[label],2)," s\n",sep="");flush.console()}
    value
  }
  raw<-timed("read_cdf",GCMS_read_cdf(cdf_file,time_range));Y<-raw$Y;n<-nrow(Y)
  if(n<9L||nwindows>n) stop("Use at least nine scans and at most one PSF window per scan.",call.=FALSE)
  censor<-if(!is.null(control$censor)) control$censor else
    if(is.list(family)&&!is.null(family$scalar)) family$scalar$censor else .5
  noise<-timed("noise",estimateSignalNoise(Y,family,dispersion,theta,
    correlation=correlation,censor=censor,ncores=ncores))
  spec<-noise$spec;factor<-spec$information_factor
  working_weight<-noise$working_weight
  standard <- NULL
  if (!is.null(alkanes_file) && is.null(psf_control$kernel_est) && is.null(psf_control$standard)) {
    std <- timed("read_standard", if (identical(alkanes_file, cdf_file) &&
      identical(calibration_range, time_range)) raw else GCMS_read_cdf(alkanes_file, calibration_range))
    standard <- std[c("Y", "time")]
  }
  direct <- c("standard", "method", "precluster", "weights", "offset")
  settings <- psf_control[setdiff(names(psf_control), c(direct, "control"))]
  settings <- utils::modifyList(if (is.null(psf_control$control)) list() else psf_control$control,
    settings, keep.null = TRUE)
  settings <- utils::modifyList(list(censor = censor), settings, keep.null = TRUE)
  settings$fit <- utils::modifyList(list(IC = if (is.character(lambda)) lambda else "gic"),
    if (is.null(settings$fit)) list() else settings$fit, keep.null = TRUE)
  args <- utils::modifyList(list(y = Y, family = family, time = raw$time,
    standard = standard, nwindows = nwindows, precluster = 1L,
    dispersion = spec$dispersion, theta = if (spec$name == "nb") spec$theta else NULL,
    weights = 1/factor, ncores = ncores, control = settings, verbose = verbose),
    psf_control[intersect(names(psf_control), direct)], keep.null = TRUE)
  blind <- timed("estimatePSF", do.call(estimatePSF, args))
  calibration <- blind$calibration
  X <- blind$X
  width <- max(1, blind$width_scans)
  B <- GCMS_background(raw$time, width, baseline_df)
  baseline_df <- ncol(B)
  fit_args<-list(y=Y,X=X,family=family,lambda=lambda,background=B,precluster=precluster,
    dispersion=spec$dispersion,theta=if(spec$name=="nb") spec$theta*(if(spec$theta_update) -1 else 1) else NULL,
    correlation=spec$correlation,ncores=ncores,control=control,verbose=verbose)
  model<-timed("factorization",if (initial_only) {
    # Joint refinement follows across samples. Stop after the independent start.
    do.call(logconNMF::splogconNMF,fit_args)
  } else {
    if (is.numeric(lambda) && !spec$kind %in% c(1L,2L)) fit_args$lambda<-lambda/ncol(Y)
    do.call(logconNMF,c(fit_args,list(time=raw$time,objective.trace=objective.trace,truth.profiles=truth.profiles)))
  })
  model$spec$dispersion_estimated<-spec$dispersion_estimated
  model$spec$theta_estimated<-spec$theta_estimated
  model$spec$correlation_estimate<-spec$correlation_estimate
  model$spec$noise_diagnostics<-spec$noise_diagnostics
  model$nuisance_df<-as.integer(spec$dispersion_estimated)+as.integer(spec$theta_estimated)
  if (is.null(model$conditional_objective)) model$ic_df<-ncol(Y)*model$rank+model$nuisance_df else {
    model$ic_df <- model$conditional_objective$shape_df + model$conditional_objective$spectral_df + model$nuisance_df
    model$objective <- -2*model$loglik + model$lambda*model$ic_df
  }
  # GCMSprime estimates noise before handing the dispersion to logconNMF.
  if (!is.null(model$gic_gap)) model$gic_gap <- logconNMF::gicGap(model)
  compounds<-GCMS_compounds(model,raw$time,sample_name)
  compounds$apex_scan<-raw$scans[compounds$apex_scan]
  model$y<-model$mu<-NULL
  if(!is.null(model$aggregation$model)) model$aggregation$model$mu<-NULL
  object<-structure(list(model=model,compounds=compounds,psf=blind,background_df=baseline_df,
    psf_standard=calibration,psf_width_scans=width,time=raw$time,mass=raw$mass,
    scans=raw$scans,psf_working_weight=working_weight,
    cdf_file=if(grepl("^https?://",cdf_file)) cdf_file else normalizePath(cdf_file,winslash="/"),
    alkanes_file=if(is.null(alkanes_file)) NULL else normalizePath(alkanes_file,winslash="/",mustWork=FALSE),
    sample_name=sample_name,msp_file=msp_file,xlsx_file=xlsx_file,ion_threshold=ion_threshold,
    seconds=c(seconds,total=proc.time()[["elapsed"]]-begun)),class="GCMSdeco")
  if (!is.null(model$gic_gap)) object$gic_gap <- model$gic_gap
  if(!is.null(library)) object<-timed("librarySearch",do.call(identifyCompounds,
    c(list(x=object,library=library),search)))
  object$compounds<-timed("write_msp",GCMS_write_msp(model,raw$time,raw$mass,msp_file,object$compounds,ion_threshold))
  if(!is.null(xlsx_file)) timed("write_xlsx",GCMS_write_xlsx(model,raw$time,raw$mass,
    object$compounds,xlsx_file,cdf_file,alkanes_file,seconds,
    matches=if(is.null(object$identification)) NULL else object$identification$matches,
    calibration=if(is.null(object$identification)) NULL else object$identification$calibration,
    search_settings=if(is.null(object$identification)) NULL else object$identification$settings,
    ion_threshold=ion_threshold))
  object$msp_file<-normalizePath(msp_file,winslash="/")
  object$xlsx_file<-if(is.null(xlsx_file)) NULL else normalizePath(xlsx_file,winslash="/")
  seconds["total"]<-proc.time()[["elapsed"]]-begun;object$seconds<-seconds
  object
}

#' @rdname gcmsDeco
#' @export
coef.GCMSdeco <- function(object,...,normalize=c("none","l1"),ion_threshold=GCMS_ion_threshold(object)) {
  GCMS_report_spectra(stats::coef(object$model,...),ion_threshold,match.arg(normalize)=="l1")
}
#' @rdname gcmsDeco
#' @export
fitted.GCMSdeco <- function(object,...) stats::fitted(object$model,...)
#' @rdname gcmsDeco
#' @export
nobs.GCMSdeco <- function(object,...) stats::nobs(object$model,...)
#' @rdname gcmsDeco
#' @export
logLik.GCMSdeco <- function(object,...) stats::logLik(object$model,...)
#' @rdname gcmsDeco
#' @export
AIC.GCMSdeco <- function(object,...,k=2) stats::AIC(object$model,...,k=k)
#' @rdname gcmsDeco
#' @export
BIC.GCMSdeco <- function(object,...) stats::BIC(object$model,...)
#' @rdname gcmsDeco
#' @export
GIC.GCMSdeco <- function(object,...) GIC(object$model,...)
#' @rdname gcmsDeco
#' @export
EBIC.GCMSdeco <- function(object,...) EBIC(object$model,...)
#' @rdname gcmsDeco
#' @export
MBIC.GCMSdeco <- function(object,...) MBIC(object$model,...)
#' @rdname gcmsDeco
#' @method print GCMSdeco
#' @export
print.GCMSdeco <- function(x,...) {
  cat("GC/MS deconvolution: ",x$model$rank," compounds; ",length(x$mass),
    " mass channels; ",length(x$time)," scans\n",
    "GIC = ",format(GIC(x),digits=9),"; ",round(x$seconds[["total"]],2)," s\n",
    "Spectra: ",x$msp_file,"\n",sep="")
  invisible(x)
}
